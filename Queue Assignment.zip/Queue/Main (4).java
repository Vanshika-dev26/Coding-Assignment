
public class Main {

    int a[] = new int[5];
    int front, rear;

    Main() {
        front = rear = -1;
    }

    void enqueue(int ele) {
        if (rear == 4) {
            System.out.println("Queue is full");
            return;
        }

        if (front == -1) {
            front = rear = 0;
        } else {
            rear++;
        }

        a[rear] = ele;
    }

    void dequeue() {
        if (front == -1) {
            System.out.println("Queue is empty");
            return;
        }

        System.out.println("Deleted element: " + a[front]);

        if (front == rear) {
            front = rear = -1;
        } else {
            front++;
        }
    }

    void display() {
        System.out.println("Queue elements:");

        for (int i = front; i <= rear; i++) {
            System.out.print(a[i] + " ");
        }
        System.out.println();
    }

    void displayFrontRear() {
        if (front == -1) {
            System.out.println("Queue is empty");
        } else {
            System.out.println("Front element: " + a[front]);
            System.out.println("Rear element: " + a[rear]);
        }
    }

    public static void main(String[] args) {

        Main q = new Main();

        q.enqueue(10);
        q.enqueue(20);
        q.enqueue(30);

        q.dequeue();

        q.enqueue(40);
        q.enqueue(50);

        q.display();
        q.displayFrontRear();
    }
}
