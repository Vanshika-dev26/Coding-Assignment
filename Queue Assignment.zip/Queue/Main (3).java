
import java.util.Scanner;

public class Main {

    int a[];
    int front, rear, max;

    Main(int size) {
        max = size;
        a = new int[max];
        front = rear = -1;
    }

    void enqueue(int ele) {
        if (rear == max - 1) {
            System.out.println("Queue is full");
            return;
        }

        if (front == -1) {
            front = rear = 0;
        } else {
            rear++;
        }

        a[rear] = ele;
    }

    void peekRear() {
        if (rear == -1) {
            System.out.println("Queue is empty");
        } else {
            System.out.println("Rear element: " + a[rear]);
        }
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter size: ");
        int n = sc.nextInt();

        Main q = new Main(n);

        for (int i = 0; i < n; i++) {
            int ele = sc.nextInt();
            q.enqueue(ele);
        }

        q.peekRear();

        sc.close();
    }
}
